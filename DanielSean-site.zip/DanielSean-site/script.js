(() => {
  const storageKey = "daniel-sean-theme";
  const themeBtn = document.getElementById("themeToggle");
  const body = document.body;

  function applyStoredTheme() {
    const saved = localStorage.getItem(storageKey);
    if (saved === "dark") body.classList.add("dark");
    else body.classList.remove("dark");
    syncThemeIcon();
  }

  function syncThemeIcon() {
    if (!themeBtn) return;
    themeBtn.textContent = body.classList.contains("dark") ? "☀️" : "🌙";
  }

  themeBtn?.addEventListener("click", () => {
    body.classList.toggle("dark");
    localStorage.setItem(storageKey, body.classList.contains("dark") ? "dark" : "light");
    syncThemeIcon();
  });

  applyStoredTheme();

  // Generic active nav
  const current = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".site-nav a").forEach(a => {
    const href = a.getAttribute("href");
    if (href === current) a.classList.add("active");
  });

  // Gallery behavior
  const gallery = document.getElementById("galleryCarousel");
  const refreshBtn = document.getElementById("refreshPhotosBtn");
  const leftBtn = document.querySelector(".arrow-left");
  const rightBtn = document.querySelector(".arrow-right");
  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightboxImg");

  async function initGallery() {
    if (!gallery) return;
    let images = [];
    try {
      const res = await fetch("images.json", { cache: "no-store" });
      images = await res.json();
    } catch (err) {
      images = [];
    }
    const shuffled = [...images].sort(() => Math.random() - 0.5);
    gallery.innerHTML = "";

    shuffled.forEach((src, idx) => {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "gallery-item";
      card.setAttribute("aria-label", `Open image ${idx + 1}`);

      const img = document.createElement("img");
      img.src = src;
      img.alt = `Gallery image ${idx + 1}`;
      img.loading = idx < 12 ? "eager" : "lazy";
      img.decoding = "async";
      img.addEventListener("error", () => card.remove());

      const cap = document.createElement("div");
      cap.className = "gallery-caption";
      cap.textContent = src;

      card.append(img, cap);
      card.addEventListener("click", () => {
        lightboxImg.src = src;
        lightbox.classList.add("show");
      });
      gallery.appendChild(card);
    });
  }

  refreshBtn?.addEventListener("click", initGallery);
  leftBtn?.addEventListener("click", () => gallery?.scrollBy({ left: -320, behavior: "smooth" }));
  rightBtn?.addEventListener("click", () => gallery?.scrollBy({ left: 320, behavior: "smooth" }));
  lightbox?.addEventListener("click", () => lightbox.classList.remove("show"));

  if (gallery) {
    let isDown = false, startX = 0, scrollLeft = 0;
    gallery.addEventListener("mousedown", e => {
      isDown = true;
      gallery.classList.add("dragging");
      startX = e.pageX - gallery.offsetLeft;
      scrollLeft = gallery.scrollLeft;
    });
    ["mouseleave", "mouseup"].forEach(evt => gallery.addEventListener(evt, () => {
      isDown = false;
      gallery.classList.remove("dragging");
    }));
    gallery.addEventListener("mousemove", e => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - gallery.offsetLeft;
      const walk = (x - startX) * 1.8;
      gallery.scrollLeft = scrollLeft - walk;
    });
  }

  // Blog cards from posts.json
  async function initBlogCards() {
    const target = document.getElementById("blogGrid");
    if (!target) return;
    try {
      const res = await fetch("posts/posts.json", { cache: "no-store" });
      const posts = await res.json();
      target.innerHTML = "";
      posts.forEach(post => {
        const article = document.createElement("article");
        article.className = "glass post-card";
        article.innerHTML = `
          <div class="post-thumb"></div>
          <div class="post-body">
            <p class="eyebrow">${post.category}</p>
            <h3>${post.title}</h3>
            <p class="post-meta">${post.date}</p>
            <p>${post.excerpt}</p>
            <a class="btn" href="posts/${post.slug}.html">Read entry</a>
          </div>
        `;
        target.appendChild(article);
      });
    } catch (err) {
      target.innerHTML = '<article class="glass post-card"><div class="post-body"><h3>Posts unavailable</h3><p>Use posts/posts.json to add or edit entries.</p></div></article>';
    }
  }

  initGallery();
  initBlogCards();
})();