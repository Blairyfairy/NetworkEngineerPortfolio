# Daniel Sean Site Starter

This folder is a clean starter inspired by the overall repo split and page types in the reference projects:
- BlairPage includes distinct pages like `index.html`, `gallery.html`, `blog.html`, plus shared `style.css`, `script.js`, and `images.json`.
- portfolio-card uses a separate compact profile-card layout with its own HTML/CSS/JS.

This version is rebuilt for Daniel Sean with placeholder networking-focused content and a comic-inspired palette:
Venom-inspired palette using near-black, blue-black, electric blue, bright red, toxic yellow, and white.

## Files
- `index.html` — main landing page with hero, experience, featured gallery, blog feed, and a built-in mobile media card
- `gallery.html` — gallery page using `images.json`
- `blog.html` — blog index fed by `posts/posts.json`
- `portfolio-card.html` — a compact profile card inside the full site
- `style.css` — shared styling
- `script.js` — theme toggle, gallery logic, blog card loader
- `images.json` — lists `img1.jpg` through `img300.jpg`
- `posts/posts.json` — blog metadata
- `posts/*.html` — starter blog entries
- `assets/` — placeholder profile and hero images

## How to edit
1. Replace `assets/profile.jpg` and `assets/hero.jpg`
2. Update placeholder links in `index.html` and `portfolio-card.html`
3. Add or replace `img#.jpg` files in the root of this folder
4. Edit `posts/posts.json` and the HTML files in `posts/`
5. Upload the folder to GitHub Pages
